package com.cg.model;

import java.io.Serializable;
import java.util.Date;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

import org.springframework.stereotype.Component;

@Entity
@Component
@Table(name="review_info")
public class Review implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(generator="revi",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="revi",sequenceName="rev",initialValue=1,allocationSize=1)
	private	int reviewId;
	
	private int rating;
	
	private String headLine;
	
	private String comment1;
	
	private Date reviewDate;
	
	
	
	public String getComment1() {
		return comment1;
	}

	public void setComment1(String comment1) {
		this.comment1 = comment1;
	}

	/*
	 * public Customer getCustomer() { return customer; }
	 * 
	 * public void setCustomer(Customer customer) { this.customer = customer; }
	 */

	@ManyToOne(targetEntity=Book.class)
	@JoinColumn(name="bookId")
	private Book book;
	/*
	 * @ManyToOne(targetEntity=Customer.class)
	 * 
	 * @JoinColumn(name="reviewBy") private Customer customer;
	 */
	
	
	public int getReviewId() {
		return reviewId;
	}
	
	public int getRating() {
		return rating;
	}
	public void setRating(int rating) {
		this.rating = rating;
	}
	public String getHeadLine() {
		return headLine;
	}
	public void setHeadLine(String headLine) {
		this.headLine = headLine;
	}
	public String getComment() {
		return comment1;
	}
	public void setComment(String comment) {
		this.comment1 = comment;
	}
	public Date getReviewDate() {
		return reviewDate;
	}
	public void setReviewDate(Date reviewDate) {
		this.reviewDate = reviewDate;
	}


	public Book getBook() {
		return book;
	}
	public void setBook(Book book) {
		this.book = book;
	}

	

	public Review(int rating, String headLine, String comment1, Date reviewDate, Book book, Customer customer) {
		super();
		this.rating = rating;
		this.headLine = headLine;
		this.comment1 = comment1;
		this.reviewDate = reviewDate;
		this.book = book;
		//this.customer = customer;
	}

	public Review() {
		super();
	}
	
}
