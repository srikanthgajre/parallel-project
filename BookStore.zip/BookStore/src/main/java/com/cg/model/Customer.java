package com.cg.model;

import javax.persistence.*;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Pattern;
import javax.validation.constraints.Size;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Entity
@Component
@Table(name="Customer_info")
public class Customer  implements Serializable{
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	@Id
	@GeneratedValue(generator="cust",strategy=GenerationType.SEQUENCE)
	@SequenceGenerator(name="cust",sequenceName="cust",initialValue=1,allocationSize=1)
    private long customerId;
	@NotEmpty(message="name is mandatory")
	private String customerName;
	@Pattern(regexp ="^[a-zA-Z0-9_!#$%&'*+/=?`{|}~^.-]+@[a-zA-Z0-9.-]+$",message="enter valid email")
	private String email;
	@Size(min=5,max=10,message="password should be between 5 to 10")
	@Pattern(regexp ="^(?=.*\\d)(?=.*[a-z])(?=.*[A-Z]).{5,10}$",message="enter password with captial letters,small letters,numbers")
	private String password;
	private String adress;
	private String city;
	private long zipcode;
	private String country; 
	@Pattern(regexp="(^$|[6-9]{1}[0-9]{9})")
	private String mobileNumber;

	/*
	 * @OneToMany(targetEntity=Review.class) private Review review;
	 */
	/*
	 * @JoinTable(name="customer_cart", joinColumns=
	 * {@JoinColumn(name="customerid")},inverseJoinColumns=
	 * {@JoinColumn(name="cart")}) private List<Book> cart=new ArrayList<Book>();
	 */
	public String getCustomerName() {
		return customerName;
	}
	public void setCustomerName(String customerName) {
		this.customerName = customerName;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public String getAdress() {
		return adress;
	}
	public void setAdress(String adress) {
		this.adress = adress;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public long getZipcode() {
		return zipcode;
	}
	public void setZipcode(long zipcode) {
		this.zipcode = zipcode;
	}
	public String getCountry() {
		return country;
	}
	public void setCountry(String country) {
		this.country = country;
	}
	public String getMobileNumber() {
		return mobileNumber;
	}
	public void setMobileNumber(String mobileNumber) {
		this.mobileNumber = mobileNumber;
	}
	public long getCustomerId() {
		return customerId;
	}
	public Customer(String customerName, String email, String password, String adress, String city, long zipcode,
			String country, String mobileNumber) {
		super();
		this.customerName = customerName;
		this.email = email;
		this.password = password;
		this.adress = adress;
		this.city = city;
		this.zipcode = zipcode;
		this.country = country;
		this.mobileNumber = mobileNumber;
	}
	@Override
	public String toString() {
		return "Customer [customerId=" + customerId + ", customerName=" + customerName + ", email=" + email
				+ ", password=" + password + ", adress=" + adress + ", city=" + city + ", zipcode=" + zipcode
				+ ", country=" + country + ", mobileNumber=" + mobileNumber + "]";
	}
	public Customer() {
		super();
	}
	
}