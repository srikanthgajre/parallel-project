package com.cg.service;

import com.cg.model.Customer;

public interface ICustomerService {

	public void newCustomer(Customer customer);

	

}
