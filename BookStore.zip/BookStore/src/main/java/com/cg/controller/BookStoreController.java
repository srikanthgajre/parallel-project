package com.cg.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.cg.dao.ICustomerDao;
import com.cg.model.Customer;
import com.cg.service.ICustomerService;



@RestController
public class BookStoreController {
	
	
	  @Autowired ICustomerService iCustomerService;
	  
	  @Autowired ICustomerDao icustomerDao;
	 
	@RequestMapping(value="home")
	public String start()
	{
		return "Welcome to Book Store";
		
	}
	
	@RequestMapping(value="customer")
	public Customer customerData()
	{   //
		Customer customer=new Customer("Srikanth", "srikanthsripatil@gmail.com", "Sri123", "H.no 123,Kukatpally", "Hyderabad", 503305, "India", "8008809987");
		iCustomerService.newCustomer(customer);
		//icustomerDao.save(customer);
		return customer;
	}
	
}
